export const initializeApp = () => ({})
